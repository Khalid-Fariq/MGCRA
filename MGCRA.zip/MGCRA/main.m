%% Modify Greater Cane Rat Algorithm (MGCRA)                                       %
%                                                                         %
%  Developed in MATLAB R2024b                                             %
%                                                                         %
%  Designed and Developed: Khalid Friq Hamajan                             %
%                                                                         %
%         E-Mail: xald.fareq@chu.edu.iq                              %               %
%_________________________________________________________________________%

clear all 
clc
 for i=1:30 % maximum number of re-run of GCRA
SearchAgents=30;  % Number of search agents
Function_name=12; % 2022
Max_iterations=500; % Maximum numbef of iterations
% for it=1:Max_iterations

Fun_name='F1';  % clasical


     
% lb=-100;             
% ub=100;              
% dim=20;              


% fobj = @(x) cec22_test_func(x', Function_name);
% [lb,ub,dim,fobj]=cec22_test_func(Function_name);
% [Best_score,Best_pos,GCRA_cg_curve]=gcra4(SearchAgents,Max_iterations,lb,ub,dim,fobj);
% [Best_score1,Best_pos1,GCRA_cg_curve1]=mgcra5(SearchAgents,Max_iterations,lb,ub,dim,fobj);
% 

% [lowerbound,upperbound,dimension,fitness]=cec22_test_func(Function_name);
% Fun_name='PressureVesselDesign'; 
% Fun_name='StringDesign';
% Fun_name='ThreeBarTruss';
% Fun_name='GearTrainDesign';
% Fun_name='CantileverBeam';
% Fun_name='WeldedBeam';
% Fun_name='AA'; 
  % Fun_name='KK'; 

% for i = 1:30;
%     fprintf('Round %d/%d\n', i, 30);
% end


 [lowerbound,upperbound,dimension,fitness]=fun_info(Fun_name); 
% [lowerbound,upperbound,dimension,fitness]=Func_eng(Fun_name); 


[Best_score,Best_pos,SHO_curve]=mgcra5(SearchAgents,Max_iterations,lowerbound,upperbound,dimension,fitness);
[Best_score1,Best_pos1,SHO_curve1]=gcra4(SearchAgents,Max_iterations,lowerbound,upperbound,dimension,fitness);
% Store best fitness value from each algorithm
    % results(Max_iterations, :) = [Best_score, Best_score1];

%  end
% 
% % Save results to a .mat file
% save('Optimization_Results.mat', 'results');
% 
% % Save results to a CSV file for external analysis
% csvwrite('Optimization_Results.csv', results);

disp('All runs completed! Results saved.');


% figure('Position',[500 500 660 290])
% %Draw search space
% subplot(1,2,1);
% fun_plot(Fun_name);
% title('Parameter space')
% xlabel('x_1');
% ylabel('x_2');
% zlabel([Fun_name,'( x_1 , x_2 )'])
% 
% % Draw objective space
% subplot(1,2,2);
% plots=semilogy(SHO_curve,'Color','g');
% set(plots,'linewidth',2)
% title('Objective space')
% xlabel('Iterations');
% ylabel('Best score');
% 
% axis tight
% grid on
% box on
% 
% legend('GCRA')

% display(['The best optimal value of the objective function found by GCRA is : ', num2str(Best_score)]);
 display (['MGCRA Iteration ' num2str(i) ' :' ' Optimal value of the MGCRA is : ', num2str(Best_score)]);
 display (['GCRA Iteration ' num2str(i) ' :' ' Optimal value of the GCRA is : ', num2str(Best_score1)]);
MGCRA(i,1)= Best_score;
GCRA(i,1)= Best_score1;
end
%  T(it,1)= Best_score;
% end

% tStart = tic;           % pair 2: tic
% n = 10;
% T = zeros(1,n);
% for i = 1:n
%     A = rand(12000,4400);
%     B = rand(12000,4400);
%     tic         % pair 1: tic
%     C = A.*B;
%     T(i)= toc;  % pair 1: toc
% end
% tMul = sum(T);
% Start the timer
tic;

% Your algorithm or code here
% Example: Simple loop for demonstration
n = 1000000;
sum_val = 0;
for i = 1:n
    sum_val = sum_val + i;
end

% Stop the timer and display the elapsed time
elapsedTime = toc;
fprintf('Elapsed time for the algorithm: %.4f seconds\n', elapsedTime);



