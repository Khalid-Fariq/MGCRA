% Modify Greater Cane Rat Algorithm (MGCRA)                                       %
%                                                                         %
%  Developed in MATLAB R2024b                                             %
%                                                                         %
%  Designed and Developed: Khalid Friq Hamajan                             %
%                                                                         %
%         E-Mail: xald.fareq@chu.edu.iq                              %__________________________________________________%

function[Score,Position,Convergence]=mgcra(Search_Agents,Max_iteration,Lower_bound,Upper_bound,dimension,objective)
%% initialize
Position=zeros(1,dimension);
Score=inf; 
% Alpha_pos=zeros(1,dimension);
% Alpha_score=inf; 
 
% Initialize the positions of search agents
Gcanerats=init(Search_Agents,dimension,Upper_bound,Lower_bound);
Convergence=zeros(1,Max_iteration);
l=1; % Loop counter

for i=1:size(Gcanerats,1)    % Main loop
       % boundary checking 
        Flag4Upper_bound=Gcanerats(i,:)>Upper_bound;
        Flag4Lower_bound=Gcanerats(i,:)<Lower_bound;
        Gcanerats(i,:)=(Gcanerats(i,:).*(~(Flag4Upper_bound+Flag4Lower_bound)))+Upper_bound.*Flag4Upper_bound+Lower_bound.*Flag4Lower_bound;               
       
    % Calculate the objective function for each search agent
        fitness=objective(Gcanerats(i,:));

        % Update Male Alpha 
        if fitness<Score 
            Score=fitness; 
            Position=Gcanerats(i,:);
            Alpha_pos1=Position;
            Alpha_score=Score;
        end
        
 end

while l<Max_iteration+1
    Alpha_pos=max(Alpha_pos1);
%     Alpha_pos=Alpha_pos1(nn);
   GR_m=randperm(Search_Agents-1,1);

   GR_rho=0.9;

    %GR_r= Alpha_score-l*(Alpha_score/Max_iteration);
   GR_r= Alpha_score.*(1/Max_iteration);

    x = 1;
    y=3;   % y=4;
    GR_mu = floor((y-x).*rand(1,1) + x);
    GR_c = rand * (l/Max_iteration); % r is a random number in [0,1]
    GR_alpha=2*GR_r*rand-GR_r;
    GR_beta=2*GR_r*GR_mu-GR_r;
    
    for i=1:size(Gcanerats,1)
        for j=1:size(Gcanerats,2)  
            Gcanerats(i,j)= (Gcanerats(i,j)+Alpha_pos)/2; 
        end
    end
    for i=1:size(Gcanerats,1)
        for j=1:size(Gcanerats,2) 
            %if rand<GR_rho    %exploration
           if rand>GR_rho
%                  dd=Alpha_pos;
                 Gcanerats(i,j)= Gcanerats(i,j)+GR_c*(Alpha_pos-GR_r*Gcanerats(i,j)); 
                 Flag4Upper_bound=Gcanerats(i,j)>Upper_bound;
                 Flag4Lower_bound=Gcanerats(i,j)<Lower_bound;
                 Gcanerats(i,:)=(Gcanerats(i,j).*(~(Flag4Upper_bound+Flag4Lower_bound)))+Upper_bound.*Flag4Upper_bound+Lower_bound.*Flag4Lower_bound;               
        
                 fitness=objective(Gcanerats(i,:));
                  if fitness<Score 
                        Score=fitness; 
                        Position=Gcanerats(i,j);
                  else
                      Gcanerats(i,j)= Gcanerats(i,j)+GR_c*(Gcanerats(i,j)-GR_alpha*Alpha_pos); 
                      Flag4Upper_bound=Gcanerats(i,j)>Upper_bound;
                      Flag4Lower_bound=Gcanerats(i,j)<Lower_bound;
                      Gcanerats(i,:)=(Gcanerats(i,j).*(~(Flag4Upper_bound+Flag4Lower_bound)))+Upper_bound.*Flag4Upper_bound+Lower_bound.*Flag4Lower_bound;               

                       fitness=objective(Gcanerats(i,:));
                      if fitness<Score 
                            Score=fitness; 
                            Position=Gcanerats(i,j);
                      end
                  end
%exploitation
            else
                
                 Gcanerats(i,j)= Gcanerats(i,j)+GR_c*(Alpha_pos-GR_mu*Gcanerats(GR_m,j));
                 Flag4Upper_bound=Gcanerats(i,j)>Upper_bound;
                 Flag4Lower_bound=Gcanerats(i,j)<Lower_bound;
                 Gcanerats(i,:)=(Gcanerats(i,j).*(~(Flag4Upper_bound+Flag4Lower_bound)))+Upper_bound.*Flag4Upper_bound+Lower_bound.*Flag4Lower_bound;               
        
                 fitness=objective(Gcanerats(i,:));
                  if fitness<Score 
                        Score=fitness; 
                        Position=Gcanerats(i,j);
                  else
                      Gcanerats(i,j)= Gcanerats(i,j)+GR_c*(Gcanerats(GR_m,j)-GR_beta*Alpha_pos); 
                      Flag4Upper_bound=Gcanerats(i,j)>Upper_bound;
                      Flag4Lower_bound=Gcanerats(i,j)<Lower_bound;
                      Gcanerats(i,:)=(Gcanerats(i,j).*(~(Flag4Upper_bound+Flag4Lower_bound)))+Upper_bound.*Flag4Upper_bound+Lower_bound.*Flag4Lower_bound;               

                      fitness=objective(Gcanerats(i,:));
                      if fitness<Score 
                            Score=fitness; 
                            Position=Gcanerats(i,j);
                      end
                  end
            end
            Alpha_pos1=Position;
            Alpha_score=Score;    
                        
        end
    end
    l=l+1;    
    Convergence(l)=Score;
end
